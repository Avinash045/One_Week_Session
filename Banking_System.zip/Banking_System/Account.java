public class Customer<String> {
    private String name;
    private String accountNumber;

    public Customer(String name, String accountNumber) {
        this.name = name;
        this.accountNumber = accountNumber;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getName() {
        return name;
    }
}

public class Account<String> {
    private String accountNumber;
    private double balance;
    private Customer customer;

    public Account(String accountNumber, Customer customer) {
        this.accountNumber = accountNumber;
        this.balance = 0.0;
        this.customer = customer;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println(amount + " deposited. New balance: " + balance);
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println(amount + "withdrawn. Balance is" + balance);
        } else if (amount > balance) {
            System.out.println("Transaction cancelled, Insufficient Amount.");
        } else {
            System.out.println("Thank You..! Visit Again.");
        }
    }

    public double getBalance() {
        return balance;
    }

    public Customer getCustomer() {
        return customer;
    }

    public String getAccountNumber() {
        return accountNumber;
    }
}

public class main {
    public static void main(String[] args) {
        Customer customer = new Customer("Avinash", "52124911");
        Account account = new Account(52124911, customer);

        System.out.println("Customer Name: " + account.getCustomer().getName());
        System.out.println("Account Number: " + account.getAccountNumber());

        account.deposit(1000);

        account.withdraw(600);

        System.out.println("Account Balance: " + account.getBalance());
    }

}
